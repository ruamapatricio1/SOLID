<?php
use PHPUnit\Framework\TestCase;
use src\Item;

class ItemTest extends TestCase{

	public function testeEstadoInicialItem(){
		$item = new Item();
		//$item->getDescricao() == '';
		//$item->getValor() == 0;

		//asserções do PHPUNIT
		$this->assertEquals('',$item->getDescricao());
		$this->assertEquals(0,$item->getValor());


	}
	

	public function testGetSetDescricao(){
		$descricao = 'Cadeira de plástico';
		$item = new Item();
		$item->setDescricao($descricao);
		$this->assertEquals($descricao, $item->getDescricao());
	}



	public function testItemValido(){

		$item = new Item();
		//seria submeter um item válido para o teste e retornar ok
		$item->setValor(55);
		$item->setDescricao('Cadeira plástico');
		$this->assertEquals(true, $item->testItemValido());
		//seria submeter um item inválido para o teste e retornar falso (descrição)
		$item->setValor(55);
		$item->setDescricao('');
		$this->assertEquals(false, $item->testItemValido());


		//seria submeter um item inválido para o teste e retornar falso (valor)
		$item->setValor(0);
		$item->setDescricao('Cadeira de plástico');
		$this->assertEquals(false, $item->testItemValido());
		

	}

/**
* @dataProvider dataValores
*
*/

	public function testGetSetValor($valor){
		$item = new Item();
		$item->setValor($valor);
		$this->assertEquals($valor, $item->getValor());
	}

	//Método provedor de dados
 	public function dataValores(){
 		return[
 			[100] ,
 			[-2],
 			[0] 
 		];
 	}



}
