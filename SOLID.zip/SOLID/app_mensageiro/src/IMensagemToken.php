<?php
namespace src;

interface IMensagemToken{
	public function enviar();
}