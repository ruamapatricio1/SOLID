<?php 

namespace src\dao;

use src\BD;
use src\interfaces\ICadastro;

class ContratoModel extends BD implements ICadastro
{
	public function salvar(){
		//lógica
	}

	
}