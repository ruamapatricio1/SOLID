<?php
namespace src\interfaces;



interface ICadastro{

	public function salvar();

}