<?php 

namespace src\componentes;

class Contrato{
	
}