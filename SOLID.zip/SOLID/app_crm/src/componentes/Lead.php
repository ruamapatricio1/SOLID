<?php 

namespace src\componentes;

class Lead{
	
}