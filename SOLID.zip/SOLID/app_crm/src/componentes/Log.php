<?php 

namespace src\componentes;

class Log{
	
}