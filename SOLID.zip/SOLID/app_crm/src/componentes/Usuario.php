<?php 

namespace src\componentes;

class Usuario{
	
}