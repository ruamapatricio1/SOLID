<?php 

namespace src;

class BD{

	private $conexao;

	protected function conectar(){
		//lógica

	}
	
}